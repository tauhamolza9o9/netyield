from sqlalchemy.orm import Session
from models.user import User
from models.withdrawal import Withdrawal
from models.audit_log import AuditLog
from core.exceptions import AppException

def ensure_admin(user: User):
    if not user.is_admin:
        raise AppException("Admin access required", 403)

def block_user(db: Session, admin_id: int, user_id: int):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise AppException("User not found", 404)

    user.is_active = False
    db.add(AuditLog(
        admin_id=admin_id,
        action="block_user",
        target_id=user_id
    ))
    db.commit()

def approve_withdrawal(db: Session, admin_id: int, withdrawal_id: int):
    withdrawal = db.query(Withdrawal).filter(
        Withdrawal.id == withdrawal_id,
        Withdrawal.status == "pending"
    ).first()

    if not withdrawal:
        raise AppException("Withdrawal not found", 404)

    withdrawal.status = "approved"

    db.add(AuditLog(
        admin_id=admin_id,
        action="approve_withdrawal",
        target_id=withdrawal_id
    ))
    db.commit()

def reject_withdrawal(db: Session, admin_id: int, withdrawal_id: int):
    withdrawal = db.query(Withdrawal).filter(
        Withdrawal.id == withdrawal_id,
        Withdrawal.status == "pending"
    ).first()

    if not withdrawal:
        raise AppException("Withdrawal not found", 404)

    withdrawal.status = "rejected"

    db.add(AuditLog(
        admin_id=admin_id,
        action="reject_withdrawal",
        target_id=withdrawal_id
    ))
    db.commit()
