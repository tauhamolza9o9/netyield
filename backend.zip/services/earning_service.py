import secrets
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from models.ad_session import AdSession
from models.earning import Earning
from models.balance import UserBalance
from models.daily_bonus import DailyBonus
from core.exceptions import AppException
from utils.rate_limiter import check_rate_limit
from services.referral_service import process_referral_payout
from models.membership import Membership

AD_REWARD = 1.0
BONUS_AMOUNT = 5.0



def start_ad_session(db: Session, user_id: int):
    if not check_rate_limit(user_id, limit=20, window_sec=86400):
        raise AppException("Daily ad limit reached")

    session_id = secrets.token_hex(16)

    ad = AdSession(user_id=user_id, session_id=session_id)
    db.add(ad)
    process_referral_payout(db, user_id, AD_REWARD)
    process_referral_payout(db, user_id, BONUS_AMOUNT)
    db.commit()

    return session_id

def complete_ad_session(db: Session, user_id: int, session_id: str):
    ad = db.query(AdSession).filter(
        AdSession.session_id == session_id,
        AdSession.user_id == user_id,
        AdSession.completed == False
    ).first()

    if not ad:
        raise AppException("Invalid or expired ad session")

    ad.completed = True

    db.add(Earning(
        user_id=user_id,
        amount=AD_REWARD,
        source="ad"
    ))

    balance = db.query(UserBalance).filter(
        UserBalance.user_id == user_id
    ).with_for_update().first()

    balance.balance += AD_REWARD

    db.commit()

def claim_daily_bonus(db: Session, user_id: int):
    now = datetime.utcnow()
    bonus = db.query(DailyBonus).filter(
        DailyBonus.user_id == user_id
    ).first()

    if not bonus:
        bonus = DailyBonus(user_id=user_id, streak=0)
        db.add(bonus)
        db.commit()

    if bonus.last_claimed and now - bonus.last_claimed < timedelta(hours=24):
        raise AppException("Daily bonus already claimed")

    bonus.streak += 1
    bonus.last_claimed = now

    db.add(Earning(
        user_id=user_id,
        amount=BONUS_AMOUNT,
        source="daily_bonus"
    ))

    balance = db.query(UserBalance).filter(
        UserBalance.user_id == user_id
    ).with_for_update().first()

    balance.balance += BONUS_AMOUNT

    db.commit()

    return BONUS_AMOUNT, bonus.streak
