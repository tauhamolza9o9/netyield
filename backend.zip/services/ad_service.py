import uuid
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List
from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_
import logging
from models.user import User
from models.ad_session import AdSession
from models.earning import Earning, EarningType, EarningStatus
from app.config import settings
from services.fraud_service import FraudService
from services.referral_service import ReferralService

logger = logging.getLogger(__name__)

class AdService:
    
    @staticmethod
    def get_available_ads(db: Session, user_id: int) -> List[Dict[str, Any]]:
        """Get list of available ads for user"""
        try:
            # Check user status
            user = db.query(User).filter(User.id == user_id).first()
            if not user or not user.is_active or user.is_suspended:
                return []
            
            # Check daily limit
            today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
            today_ads = db.query(AdSession).filter(
                AdSession.user_id == user_id,
                AdSession.started_at >= today_start,
                AdSession.status == "completed"
            ).count()
            
            max_ads_per_day = 100  # Configurable
            if today_ads >= max_ads_per_day:
                return []
            
            # Get ads based on user's country, interests, etc.
            # For MVP, return static ads
            ads = [
                {
                    "ad_id": "ad_001",
                    "title": "Mobile Game Advertisement",
                    "duration": 30,  # seconds
                    "reward": settings.RATE_PER_AD * user.membership_multiplier,
                    "thumbnail": "/static/ads/game_ad.jpg",
                    "description": "Watch this game trailer and earn money",
                    "category": "gaming",
                    "requires_interaction": False
                },
                {
                    "ad_id": "ad_002",
                    "title": "E-commerce Store Promotion",
                    "duration": 45,
                    "reward": settings.RATE_PER_AD * user.membership_multiplier * 1.5,
                    "thumbnail": "/static/ads/ecom_ad.jpg",
                    "description": "Check out our latest products",
                    "category": "shopping",
                    "requires_interaction": True
                },
                {
                    "ad_id": "ad_003",
                    "title": "App Install Campaign",
                    "duration": 60,
                    "reward": settings.RATE_PER_AD * user.membership_multiplier * 2.0,
                    "thumbnail": "/static/ads/app_ad.jpg",
                    "description": "Install and open our app",
                    "category": "apps",
                    "requires_interaction": True
                }
            ]
            
            return ads
            
        except Exception as e:
            logger.error(f"Error getting available ads: {e}")
            return []
    
    @staticmethod
    def start_ad_session(
        db: Session, 
        user_id: int, 
        ad_id: str, 
        request_info: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Start a new ad watching session"""
        try:
            # Get user
            user = db.query(User).filter(User.id == user_id).first()
            if not user or not user.is_active:
                return {"success": False, "message": "User not found or inactive"}
            
            # Fraud check
            fraud_check = FraudService.check_ad_fraud(db, user_id, request_info)
            if not fraud_check["allowed"]:
                return {"success": False, "message": fraud_check["reason"]}
            
            # Get ad details
            available_ads = AdService.get_available_ads(db, user_id)
            ad_details = next((ad for ad in available_ads if ad["ad_id"] == ad_id), None)
            
            if not ad_details:
                return {"success": False, "message": "Ad not available"}
            
            # Create session
            session_id = str(uuid.uuid4())
            expires_at = datetime.utcnow() + timedelta(minutes=10)
            
            ad_session = AdSession(
                user_id=user_id,
                session_id=session_id,
                ad_id=ad_id,
                ad_title=ad_details["title"],
                ad_duration=ad_details["duration"],
                ad_reward=ad_details["reward"],
                ip_address=request_info.get("ip_address", ""),
                user_agent=request_info.get("user_agent", ""),
                device_id=request_info.get("device_id", ""),
                expires_at=expires_at,
                status="active"
            )
            
            db.add(ad_session)
            db.commit()
            db.refresh(ad_session)
            
            return {
                "success": True,
                "session_id": session_id,
                "ad_details": ad_details,
                "expires_at": expires_at.isoformat(),
                "message": "Ad session started"
            }
            
        except Exception as e:
            db.rollback()
            logger.error(f"Error starting ad session: {e}")
            return {"success": False, "message": "Failed to start ad session"}
    
    @staticmethod
    def track_ad_progress(
        db: Session, 
        session_id: str, 
        user_id: int, 
        watched_duration: int
    ) -> Dict[str, Any]:
        """Track ad watching progress"""
        try:
            session = db.query(AdSession).filter(
                AdSession.session_id == session_id,
                AdSession.user_id == user_id,
                AdSession.status == "active"
            ).first()
            
            if not session:
                return {"success": False, "message": "Session not found or expired"}
            
            if session.expires_at < datetime.utcnow():
                session.status = "expired"
                db.commit()
                return {"success": False, "message": "Session expired"}
            
            # Update progress
            session.watched_duration = watched_duration
            session.completion_percentage = (watched_duration / session.ad_duration) * 100
            
            # Check if completed
            if watched_duration >= session.ad_duration:
                session.completion_percentage = 100
                session.watched_duration = session.ad_duration
            
            db.commit()
            
            return {
                "success": True,
                "completion_percentage": session.completion_percentage,
                "remaining_seconds": max(0, session.ad_duration - watched_duration),
                "is_completed": session.completion_percentage >= 100
            }
            
        except Exception as e:
            db.rollback()
            logger.error(f"Error tracking ad progress: {e}")
            return {"success": False, "message": "Progress tracking failed"}
    
    @staticmethod
    def complete_ad_session(
        db: Session, 
        session_id: str, 
        user_id: int, 
        completion_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Complete ad session and credit earnings"""
        try:
            session = db.query(AdSession).filter(
                AdSession.session_id == session_id,
                AdSession.user_id == user_id
            ).first()
            
            if not session:
                return {"success": False, "message": "Session not found"}
            
            if session.status == "completed":
                return {"success": False, "message": "Session already completed"}
            
            if session.expires_at < datetime.utcnow():
                session.status = "expired"
                db.commit()
                return {"success": False, "message": "Session expired"}
            
            # Fraud validation
            fraud_score = FraudService.validate_ad_completion(db, session, completion_data)
            if fraud_score > 0.7:  # High fraud probability
                session.status = "failed"
                session.is_suspicious = True
                session.fraud_score = fraud_score
                session.fraud_reason = "Suspicious completion patterns"
                db.commit()
                return {"success": False, "message": "Completion rejected due to fraud detection"}
            
            # Calculate earnings
            user = db.query(User).filter(User.id == user_id).first()
            if not user:
                return {"success": False, "message": "User not found"}
            
            # Apply membership multiplier
            earnings = session.ad_reward * user.membership_multiplier
            
            # Create earning record
            earning = Earning(
                user_id=user_id,
                amount=earnings,
                type=EarningType.AD_WATCH,
                status=EarningStatus.COMPLETED,
                description=f"Ad watch: {session.ad_title}",
                session_id=session_id,
                base_amount=session.ad_reward,
                multiplier_applied=user.membership_multiplier,
                metadata=str(completion_data)
            )
            
            # Update user balance
            user.balance += earnings
            user.total_earned += earnings
            
            # Update session
            session.status = "completed"
            session.completed_at = datetime.utcnow()
            session.is_completed = True
            session.credited_amount = earnings
            session.multiplier_applied = user.membership_multiplier
            
            db.add(earning)
            db.commit()
            
            # Process referral commissions
            ReferralService.process_commission(
                db, user_id, earnings, "ad_watch", session_id
            )
            
            # Log completion
            logger.info(f"Ad completed: User {user_id} earned ₹{earnings} for session {session_id}")
            
            return {
                "success": True,
                "amount_earned": float(earnings),
                "new_balance": float(user.balance),
                "message": "Ad completed successfully! Earnings credited."
            }
            
        except Exception as e:
            db.rollback()
            logger.error(f"Error completing ad session: {e}")
            return {"success": False, "message": "Failed to complete ad session"}
    
    @staticmethod
    def get_user_ad_stats(db: Session, user_id: int) -> Dict[str, Any]:
        """Get user's ad watching statistics"""
        try:
            today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
            
            # Today's stats
            today_ads = db.query(AdSession).filter(
                AdSession.user_id == user_id,
                AdSession.started_at >= today_start,
                AdSession.status == "completed"
            ).all()
            
            today_earnings = sum([float(session.credited_amount) for session in today_ads])
            
            # Total stats
            total_ads = db.query(AdSession).filter(
                AdSession.user_id == user_id,
                AdSession.status == "completed"
            ).count()
            
            total_earnings = db.query(func.sum(Earning.amount)).filter(
                Earning.user_id == user_id,
                Earning.type == EarningType.AD_WATCH,
                Earning.status == EarningStatus.COMPLETED
            ).scalar() or 0
            
            return {
                "today": {
                    "ads_watched": len(today_ads),
                    "earnings": float(today_earnings),
                    "average_per_ad": float(today_earnings / len(today_ads)) if today_ads else 0
                },
                "total": {
                    "ads_watched": total_ads,
                    "earnings": float(total_earnings),
                    "average_per_ad": float(total_earnings / total_ads) if total_ads else 0
                },
                "limits": {
                    "daily_limit": 100,
                    "ads_today": len(today_ads),
                    "remaining_today": max(0, 100 - len(today_ads))
                }
            }
            
        except Exception as e:
            logger.error(f"Error getting ad stats: {e}")
            return {}