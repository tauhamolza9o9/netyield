from sqlalchemy.orm import Session
from models.user import User
from models.referral import ReferralEarning
from models.earning import Earning
from models.balance import UserBalance
from core.constants import (
    REFERRAL_LEVEL_1,
    REFERRAL_LEVEL_2,
    REFERRAL_LEVEL_3
)

LEVEL_MAP = {
    1: REFERRAL_LEVEL_1,
    2: REFERRAL_LEVEL_2,
    3: REFERRAL_LEVEL_3
}

def process_referral_payout(
    db: Session,
    earner_id: int,
    base_amount: float
):
    current_user = db.query(User).filter(User.id == earner_id).first()

    for level in range(1, 4):
        if not current_user or not current_user.referred_by:
            break

        referrer = db.query(User).filter(
            User.referral_code == current_user.referred_by
        ).first()

        if not referrer:
            break

        commission = round(base_amount * LEVEL_MAP[level], 2)

        db.add(ReferralEarning(
            user_id=referrer.id,
            from_user_id=earner_id,
            level=level,
            amount=commission
        ))

        db.add(Earning(
            user_id=referrer.id,
            amount=commission,
            source=f"referral_level_{level}"
        ))

        balance = db.query(UserBalance).filter(
            UserBalance.user_id == referrer.id
        ).with_for_update().first()

        balance.balance += commission

        current_user = referrer

    db.commit()
