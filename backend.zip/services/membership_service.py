from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from models.membership import Membership
from core.exceptions import AppException

PLANS = {
    "silver": {"multiplier": 1.2, "days": 30},
    "gold": {"multiplier": 1.5, "days": 30},
}

def upgrade_membership(db: Session, user_id: int, plan: str):
    if plan not in PLANS:
        raise AppException("Invalid membership plan")

    data = PLANS[plan]
    expires_at = datetime.utcnow() + timedelta(days=data["days"])

    membership = db.query(Membership).filter(
        Membership.user_id == user_id
    ).first()

    if membership:
        membership.plan = plan
        membership.multiplier = data["multiplier"]
        membership.expires_at = expires_at
    else:
        membership = Membership(
            user_id=user_id,
            plan=plan,
            multiplier=data["multiplier"],
            expires_at=expires_at
        )
        db.add(membership)

    db.commit()

def get_membership_status(db: Session, user_id: int):
    membership = db.query(Membership).filter(
        Membership.user_id == user_id
    ).first()

    if not membership or (membership.expires_at and membership.expires_at < datetime.utcnow()):
        return {
            "plan": "free",
            "multiplier": 1.0,
            "expires_at": None
        }

    return {
        "plan": membership.plan,
        "multiplier": membership.multiplier,
        "expires_at": membership.expires_at.isoformat()
    }
