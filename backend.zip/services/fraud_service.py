from sqlalchemy.orm import Session
from models.device import Device
from models.user import User

RISK_THRESHOLD = 100

def register_activity(
    db: Session,
    user_id: int,
    fingerprint: str,
    ip: str,
    risk_delta: int = 1
):
    device = db.query(Device).filter(
        Device.fingerprint == fingerprint,
        Device.user_id == user_id
    ).first()

    if not device:
        device = Device(
            user_id=user_id,
            fingerprint=fingerprint,
            ip_address=ip,
            risk_score=risk_delta
        )
        db.add(device)
    else:
        device.risk_score += risk_delta

    if device.risk_score >= RISK_THRESHOLD:
        user = db.query(User).filter(User.id == user_id).first()
        if user:
            user.is_active = False

    db.commit()
