from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import date
from models.balance import UserBalance
from models.earning import Earning

def get_dashboard_data(db: Session, user_id: int):
    balance_row = db.query(UserBalance).filter(
        UserBalance.user_id == user_id
    ).first()

    balance = balance_row.balance if balance_row else 0.0

    today_earnings = db.query(
        func.coalesce(func.sum(Earning.amount), 0)
    ).filter(
        Earning.user_id == user_id,
        func.date(Earning.created_at) == date.today()
    ).scalar()

    total_earnings = db.query(
        func.coalesce(func.sum(Earning.amount), 0)
    ).filter(
        Earning.user_id == user_id
    ).scalar()

    return {
        "balance": round(balance, 2),
        "today_earnings": round(today_earnings, 2),
        "total_earnings": round(total_earnings, 2)
    }
