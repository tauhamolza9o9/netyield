from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import func
from models.withdrawal import Withdrawal
from models.balance import UserBalance
from core.exceptions import AppException
from core.constants import MIN_WITHDRAW_AMOUNT

WITHDRAW_FEE_PERCENT = 0.05
WEEKLY_LIMIT = 2

def request_withdrawal(db: Session, user_id: int, amount: float, upi_id: str):
    if amount < MIN_WITHDRAW_AMOUNT:
        raise AppException(f"Minimum withdrawal is ₹{MIN_WITHDRAW_AMOUNT}")

    one_week_ago = datetime.utcnow() - timedelta(days=7)

    count = db.query(func.count(Withdrawal.id)).filter(
        Withdrawal.user_id == user_id,
        Withdrawal.created_at >= one_week_ago
    ).scalar()

    if count >= WEEKLY_LIMIT:
        raise AppException("Weekly withdrawal limit reached")

    balance = db.query(UserBalance).filter(
        UserBalance.user_id == user_id
    ).with_for_update().first()

    if not balance or balance.balance < amount:
        raise AppException("Insufficient balance")

    fee = round(amount * WITHDRAW_FEE_PERCENT, 2)
    net_amount = amount - fee

    balance.balance -= amount

    withdrawal = Withdrawal(
        user_id=user_id,
        amount=net_amount,
        fee=fee,
        upi_id=upi_id
    )

    db.add(withdrawal)
    db.commit()

def get_withdrawal_history(db: Session, user_id: int):
    return db.query(Withdrawal).filter(
        Withdrawal.user_id == user_id
    ).order_by(Withdrawal.created_at.desc()).all()
