from sqlalchemy.orm import Session
from models.shortlink import ShortLink
from models.earning import Earning
from models.balance import UserBalance
from utils.shortcode_generator import generate_shortcode
from core.exceptions import AppException
from services.referral_service import process_referral_payout

SHORTLINK_REWARD = 2.0

def create_shortlink(db: Session, user_id: int, original_url: str):
    code = generate_shortcode()

    link = ShortLink(
        user_id=user_id,
        original_url=original_url,
        code=code
    )

    db.add(link)
    db.commit()
    db.refresh(link)

    return code

def resolve_shortlink(db: Session, code: str):
    link = db.query(ShortLink).filter(
        ShortLink.code == code,
        ShortLink.is_active == True
    ).first()

    if not link:
        raise AppException("Link not found", 404)

    # credit owner
    db.add(Earning(
        user_id=link.user_id,
        amount=SHORTLINK_REWARD,
        source="shortlink"
    ))

    balance = db.query(UserBalance).filter(
        UserBalance.user_id == link.user_id
    ).with_for_update().first()

    balance.balance += SHORTLINK_REWARD

    process_referral_payout(db, link.user_id, SHORTLINK_REWARD)

    db.commit()
    return link.original_url
