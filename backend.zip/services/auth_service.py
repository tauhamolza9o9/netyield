import secrets
from sqlalchemy.orm import Session
from models.user import User
from utils.security import (
    hash_password,
    verify_password,
    create_access_token,
    create_refresh_token
)
from core.exceptions import AppException
from models.balance import UserBalance



def generate_referral_code():
    return secrets.token_hex(4)

def register_user(db: Session, email: str, password: str, referral_code: str | None):
    existing = db.query(User).filter(User.email == email).first()
    if existing:
        raise AppException("Email already registered")

    user = User(
        email=email,
        password_hash=hash_password(password),
        referral_code=generate_referral_code(),
        referred_by=referral_code
    )

    db.add(user)
    db.commit()
    db.refresh(user)
    db.add(UserBalance(user_id=user.id, balance=0.0))
    db.commit()

    return {
        "access_token": create_access_token(user.id),
        "refresh_token": create_refresh_token(user.id)
    }

def login_user(db: Session, email: str, password: str):
    user = db.query(User).filter(User.email == email).first()
    if not user or not verify_password(password, user.password_hash):
        raise AppException("Invalid credentials")

    if not user.is_active:
        raise AppException("Account blocked")

    return {
        "access_token": create_access_token(user.id),
        "refresh_token": create_refresh_token(user.id)
    }
