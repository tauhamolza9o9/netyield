from fastapi import APIRouter, Depends
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from schemas.shortlink import ShortLinkCreate, ShortLinkResponse
from services.shortlink_service import create_shortlink, resolve_shortlink
from app.dependencies import get_db, get_current_user

router = APIRouter(tags=["Shortlink"])

@router.post("/shortlink/create", response_model=ShortLinkResponse)
def create(
    data: ShortLinkCreate,
    db: Session = Depends(get_db),
    user = Depends(get_current_user)
):
    code = create_shortlink(db, user.id, str(data.original_url))
    return {"short_url": f"/r/{code}"}

@router.get("/r/{code}")
def redirect(code: str, db: Session = Depends(get_db)):
    url = resolve_shortlink(db, code)
    return RedirectResponse(url)
