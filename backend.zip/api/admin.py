from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.dependencies import get_db, get_current_user
from schemas.admin import AdminActionResponse
from services.admin_service import (
    ensure_admin,
    block_user,
    approve_withdrawal,
    reject_withdrawal
)

router = APIRouter(prefix="/admin", tags=["Admin"])

@router.post("/block-user/{user_id}", response_model=AdminActionResponse)
def block(
    user_id: int,
    db: Session = Depends(get_db),
    admin = Depends(get_current_user)
):
    ensure_admin(admin)
    block_user(db, admin.id, user_id)
    return {"status": "blocked"}

@router.post("/withdraw/approve/{withdrawal_id}", response_model=AdminActionResponse)
def approve(
    withdrawal_id: int,
    db: Session = Depends(get_db),
    admin = Depends(get_current_user)
):
    ensure_admin(admin)
    approve_withdrawal(db, admin.id, withdrawal_id)
    return {"status": "approved"}

@router.post("/withdraw/reject/{withdrawal_id}", response_model=AdminActionResponse)
def reject(
    withdrawal_id: int,
    db: Session = Depends(get_db),
    admin = Depends(get_current_user)
):
    ensure_admin(admin)
    reject_withdrawal(db, admin.id, withdrawal_id)
    return {"status": "rejected"}
