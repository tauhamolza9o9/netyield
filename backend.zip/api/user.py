# app/api/user.py

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.dependencies import get_db, get_current_user
from schemas.user import UserProfileResponse

router = APIRouter(prefix="/user", tags=["User"])

@router.get("/me", response_model=UserProfileResponse)
def get_profile(
    db: Session = Depends(get_db),
    user = Depends(get_current_user)
):
    return {
        "id": user.id,
        "email": user.email,
        "is_active": user.is_active,
        "is_admin": user.is_admin
    }
