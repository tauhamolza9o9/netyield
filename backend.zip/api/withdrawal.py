from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from schemas.withdrawal import WithdrawalRequest, WithdrawalResponse
from services.withdrawal_service import (
    request_withdrawal,
    get_withdrawal_history
)
from app.dependencies import get_db, get_current_user

router = APIRouter(prefix="/withdraw", tags=["Withdrawal"])

@router.post("/request", response_model=WithdrawalResponse)
def withdraw(
    data: WithdrawalRequest,
    db: Session = Depends(get_db),
    user = Depends(get_current_user)
):
    request_withdrawal(db, user.id, data.amount, data.upi_id)
    return {"status": "pending"}

@router.get("/history")
def history(
    db: Session = Depends(get_db),
    user = Depends(get_current_user)
):
    return get_withdrawal_history(db, user.id)
