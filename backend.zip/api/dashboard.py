from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from schemas.dashboard import DashboardResponse
from services.dashboard_service import get_dashboard_data
from app.dependencies import get_db, get_current_user

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])

@router.get("/", response_model=DashboardResponse)
def dashboard(
    db: Session = Depends(get_db),
    user = Depends(get_current_user)
):
    return get_dashboard_data(db, user.id)
