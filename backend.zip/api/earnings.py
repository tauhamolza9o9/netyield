from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from schemas.earnings import AdStartResponse, DailyBonusResponse
from services.earning_service import (
    start_ad_session,
    complete_ad_session,
    claim_daily_bonus
)
from app.dependencies import get_db, get_current_user

router = APIRouter(prefix="/earn", tags=["Earnings"])

@router.post("/ad/start", response_model=AdStartResponse)
def start_ad(
    db: Session = Depends(get_db),
    user = Depends(get_current_user)
):
    session_id = start_ad_session(db, user.id)
    return {"session_id": session_id}

@router.post("/ad/complete")
def complete_ad(
    session_id: str,
    db: Session = Depends(get_db),
    user = Depends(get_current_user)
):
    complete_ad_session(db, user.id, session_id)
    return {"status": "credited"}

@router.post("/daily-bonus", response_model=DailyBonusResponse)
def daily_bonus(
    db: Session = Depends(get_db),
    user = Depends(get_current_user)
):
    amount, streak = claim_daily_bonus(db, user.id)
    return {"amount": amount, "streak": streak}
