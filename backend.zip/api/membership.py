from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from schemas.membership import (
    MembershipUpgradeRequest,
    MembershipStatusResponse
)
from services.membership_service import (
    upgrade_membership,
    get_membership_status
)
from app.dependencies import get_db, get_current_user

router = APIRouter(prefix="/membership", tags=["Membership"])

@router.post("/upgrade")
def upgrade(
    data: MembershipUpgradeRequest,
    db: Session = Depends(get_db),
    user = Depends(get_current_user)
):
    upgrade_membership(db, user.id, data.plan)
    return {"status": "upgraded"}

@router.get("/status", response_model=MembershipStatusResponse)
def status(
    db: Session = Depends(get_db),
    user = Depends(get_current_user)
):
    return get_membership_status(db, user.id)
