from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from schemas.auth import RegisterRequest, LoginRequest, TokenResponse
from services.auth_service import register_user, login_user
from app.dependencies import get_db

router = APIRouter(prefix="/auth", tags=["Auth"])

@router.post("/register", response_model=TokenResponse)
def register(data: RegisterRequest, db: Session = Depends(get_db)):
    tokens = register_user(
        db,
        data.email,
        data.password,
        data.referral_code
    )
    return tokens

@router.post("/login", response_model=TokenResponse)
def login(data: LoginRequest, db: Session = Depends(get_db)):
    tokens = login_user(db, data.email, data.password)
    return tokens
