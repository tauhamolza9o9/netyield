from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.dependencies import get_db, get_current_user
from schemas.referral import ReferralStatsResponse
from models.referral import ReferralEarning

router = APIRouter(prefix="/referral", tags=["Referral"])

@router.get("/stats", response_model=ReferralStatsResponse)
def referral_stats(
    db: Session = Depends(get_db),
    user = Depends(get_current_user)
):
    stats = (
        db.query(
            ReferralEarning.level,
            func.coalesce(func.sum(ReferralEarning.amount), 0)
        )
        .filter(ReferralEarning.user_id == user.id)
        .group_by(ReferralEarning.level)
        .all()
    )

    data = {1: 0.0, 2: 0.0, 3: 0.0}
    for level, amount in stats:
        data[level] = float(amount)

    return {
        "level_1": data[1],
        "level_2": data[2],
        "level_3": data[3],
        "total": round(sum(data.values()), 2)
    }
