from fastapi import HTTPException, status

class AppException(HTTPException):
    def __init__(self, message: str, code=status.HTTP_400_BAD_REQUEST):
        super().__init__(status_code=code, detail=message)
