import time
from workers.fraud_monitor import decay_risk_scores

while True:
    decay_risk_scores()
    time.sleep(3600)
