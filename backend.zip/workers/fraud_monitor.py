from sqlalchemy.orm import Session
from app.database import SessionLocal
from models.device import Device

def decay_risk_scores():
    db: Session = SessionLocal()
    try:
        devices = db.query(Device).all()
        for device in devices:
            if device.risk_score > 0:
                device.risk_score -= 1
        db.commit()
    finally:
        db.close()
