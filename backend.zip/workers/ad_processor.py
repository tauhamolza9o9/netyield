# placeholder for future async ad validation
def process_ads():
    pass
