from pydantic import BaseModel, HttpUrl

class ShortLinkCreate(BaseModel):
    original_url: HttpUrl

class ShortLinkResponse(BaseModel):
    short_url: str
