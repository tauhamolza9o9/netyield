from pydantic import BaseModel

class WithdrawalRequest(BaseModel):
    amount: float
    upi_id: str

class WithdrawalResponse(BaseModel):
    status: str
