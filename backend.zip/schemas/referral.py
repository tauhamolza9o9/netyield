from pydantic import BaseModel

class ReferralStatsResponse(BaseModel):
    level_1: float
    level_2: float
    level_3: float
    total: float
