from pydantic import BaseModel

class AdStartResponse(BaseModel):
    session_id: str

class DailyBonusResponse(BaseModel):
    amount: float
    streak: int
