# app/schemas/user.py

from pydantic import BaseModel, EmailStr

class UserProfileResponse(BaseModel):
    id: int
    email: EmailStr
    is_active: bool
    is_admin: bool
