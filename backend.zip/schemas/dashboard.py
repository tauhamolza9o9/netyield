from pydantic import BaseModel

class DashboardResponse(BaseModel):
    balance: float
    today_earnings: float
    total_earnings: float
