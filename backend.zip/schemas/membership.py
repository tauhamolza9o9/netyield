from pydantic import BaseModel

class MembershipUpgradeRequest(BaseModel):
    plan: str

class MembershipStatusResponse(BaseModel):
    plan: str
    multiplier: float
    expires_at: str | None
