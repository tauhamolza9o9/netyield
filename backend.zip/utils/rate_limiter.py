from datetime import datetime, timedelta

_ad_cache = {}

def check_rate_limit(user_id: int, limit: int, window_sec: int):
    now = datetime.utcnow()
    window_start = now - timedelta(seconds=window_sec)

    history = _ad_cache.get(user_id, [])
    history = [t for t in history if t > window_start]

    if len(history) >= limit:
        return False

    history.append(now)
    _ad_cache[user_id] = history
    return True
