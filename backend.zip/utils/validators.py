# utils/validators.py

import re
from core.exceptions import AppException

def validate_upi(upi_id: str):
    pattern = r"^[\w.\-]{2,256}@[a-zA-Z]{2,64}$"
    if not re.match(pattern, upi_id):
        raise AppException("Invalid UPI ID")

def validate_password(password: str):
    if len(password) < 8:
        raise AppException("Password must be at least 8 characters")
