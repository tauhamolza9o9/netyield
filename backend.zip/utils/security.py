from datetime import timedelta
from core.security import create_token, hash_password, verify_password
from app.config import settings

def create_access_token(user_id: int):
    return create_token(
        {"sub": str(user_id)},
        timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )

def create_refresh_token(user_id: int):
    return create_token(
        {"sub": str(user_id)},
        timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    )
