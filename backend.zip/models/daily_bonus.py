from sqlalchemy import Column, Integer, DateTime, ForeignKey
from sqlalchemy.sql import func
from app.database import Base

class DailyBonus(Base):
    __tablename__ = "daily_bonus"

    user_id = Column(Integer, ForeignKey("users.id"), primary_key=True)
    last_claimed = Column(DateTime(timezone=True))
    streak = Column(Integer, default=0)
