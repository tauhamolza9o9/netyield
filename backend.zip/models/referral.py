from sqlalchemy import Column, Integer, Float, String, DateTime, ForeignKey
from sqlalchemy.sql import func
from app.database import Base

class ReferralEarning(Base):
    __tablename__ = "referral_earnings"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    from_user_id = Column(Integer, index=True)
    level = Column(Integer)  # 1, 2, 3
    amount = Column(Float)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
