from sqlalchemy import Column, Integer, Float, String, DateTime, ForeignKey
from sqlalchemy.sql import func
from app.database import Base

class Earning(Base):
    __tablename__ = "earnings"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    amount = Column(Float, nullable=False)
    source = Column(String(50))  # ad, bonus, referral, shortlink
    created_at = Column(DateTime(timezone=True), server_default=func.now())
