# NetYield Backend

## Requirements
- Python 3.10+
- MySQL
- VPS (Ubuntu recommended)

## Setup
```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
