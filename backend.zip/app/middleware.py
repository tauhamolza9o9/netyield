from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from utils.logger import get_logger
from utils.device_fingerprint import generate_fingerprint
from services.fraud_service import register_activity
from app.database import SessionLocal

logger = get_logger()

class LoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)

        try:
            if "authorization" in request.headers:
                user_agent = request.headers.get("user-agent", "")
                ip = request.client.host if request.client else "unknown"
                fingerprint = generate_fingerprint(user_agent, ip)

                db = SessionLocal()
                token = request.headers.get("authorization", "")
                user_id = int(token.split(".")[1], 16) if "." in token else None

                if user_id:
                    register_activity(db, user_id, fingerprint, ip)
                db.close()
        except Exception:
            pass

        logger.info(f"{request.method} {request.url}")
        return response
