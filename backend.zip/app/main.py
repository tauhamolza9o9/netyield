from fastapi import FastAPI
from app.middleware import LoggingMiddleware
from app.config import settings
from api.auth import router as auth_router
from api.dashboard import router as dashboard_router
from api.earnings import router as earnings_router
from api.referral import router as referral_router
from api.shortlink import router as shortlink_router
from api.withdrawal import router as withdrawal_router
from api.membership import router as membership_router
from api.admin import router as admin_router
import time
from workers.fraud_monitor import decay_risk_scores
from api.user import router as user_router


app = FastAPI(title=settings.APP_NAME)

app.add_middleware(LoggingMiddleware)

app.include_router(auth_router)

app.include_router(dashboard_router)

app.include_router(earnings_router)

app.include_router(referral_router)

app.include_router(shortlink_router)

app.include_router(withdrawal_router)

app.include_router(membership_router)

app.include_router(admin_router)

app.include_router(user_router)

@app.get("/health")
def health_check():
    return {"status": "ok"}

while True:
    decay_risk_scores()
    time.sleep(3600)